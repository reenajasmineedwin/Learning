<?php 
    require_once "config.php";
    
    if(isset($_SESSION['access_token'])){
        header('Location:index.php');
        exit();
    }

    $loginURL = $gClient->createAuthUrl();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with Google</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
    <div class="container" style="margin-top:100px">
        <div class ="row justify-content-center">
            <div class="col-md-6 col-offset-3" align="center">
              
            <img src="ribbonlogo.jpg"><br><br>

            <form>
                 <input placeholder="Email..." name="email" class="form-control"><br>   
                 <input type="password" placeholder="Password..." name="password" class="form-control"><br>
                 <input type="submit" value="Log In" class="btn btn-primary">
                 <input type="button" onclick="window.location = '<?php echo $loginURL ?>';" value="Log In with Google" class="btn btn-danger">                 
            </form>

            </div>

        </div>
    </div>
    
</body>
</html>
