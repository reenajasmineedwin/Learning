<?php 
    session_start();
    if(!isset($_SESSION['access_token'])){
        header('Location:login.php');
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with Google</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
    <div class="container" style="margin-top:100px">
        <div class ="row">
            <div class="col-md-3">
              
            <img style="width:80%" src="<?php echo $_SESSION['picture'] ?>">

            </div>
            <div class="col-md-9">
              
            <table class="table table-hover table-bordered">
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td><?php echo $_SESSION['id'] ?></td>
                    </tr>
                    <tr>
                        <td>First Name</td>
                        <td><?php echo $_SESSION['givenName'] ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?php echo $_SESSION['email'] ?></td>
                    </tr>
                    <tr>
                        <td>Family Name</td>
                        <td><?php echo $_SESSION['familyName'] ?></td>
                    </tr>
                    
        
                </tbody>
            </table>  
            <?php
                    echo '<p><a href="logout.php">Logout</p>' 
                    ?>
            </div>
        </div>
    </div>
    
</body>
</html>
